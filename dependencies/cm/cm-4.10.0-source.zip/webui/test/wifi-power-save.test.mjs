import test from 'node:test';
import assert from 'node:assert/strict';
import { formatWiFiPowerSaveStatus } from '../src/wifiPowerSave.mjs';

test('WiFi driver snapshot distinguishes request, actual mode and failed reads', () => {
  const status = { requested: true, effectiveMode: 0, readError: 0, applyAttempted: true, applySucceeded: false };
  assert.match(formatWiFiPowerSaveStatus(status), /requested on; driver off.*last apply failed/);
  assert.match(formatWiFiPowerSaveStatus({ ...status, effectiveMode: 1, applySucceeded: true }), /driver on.*MIN_MODEM/);
  assert.match(formatWiFiPowerSaveStatus({ ...status, effectiveMode: 2 }), /MAX_MODEM/);
  assert.match(formatWiFiPowerSaveStatus({ ...status, effectiveMode: 1, readError: 123 }), /driver unknown.*read error 123/);
  assert.match(formatWiFiPowerSaveStatus({ ...status, effectiveMode: 99 }), /driver unknown/);
  assert.match(formatWiFiPowerSaveStatus({ ...status, applyAttempted: false }), /not attempted/);
  assert.match(formatWiFiPowerSaveStatus(status), /At settings load.*Reload settings/);
  assert.equal(formatWiFiPowerSaveStatus(undefined), '');
});
