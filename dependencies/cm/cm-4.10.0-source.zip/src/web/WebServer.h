#pragma once

#include <ESPAsyncWebServer.h>
#include <ArduinoJson.h>
#include <atomic>
#include <functional>
#include <memory>
#include <esp_system.h>
#include "../ConfigManagerConfig.h"
#include "../runtime/detail/RuntimeSelection.h"

#if CM_EMBED_WEBUI
#include "../html_content.h"
#endif

class ConfigManagerClass;

class ConfigManagerWeb {
public:
  // Callback types for integration with ConfigManager
  typedef std::function<String()> JsonProvider;
  typedef std::function<std::shared_ptr<const String>()> RuntimeMetaProvider;
  typedef std::function<void()> SimpleCallback;
  typedef std::function<bool(const String&, const String&, const String&)> SettingUpdateCallback;
  typedef std::function<void(AsyncWebServerRequest*)> RequestHandler;

private:
  AsyncWebServer* server;
  ConfigManagerClass* configManager;
  bool initialized;
  bool routesDefined;
  bool serverStarted;

  // Callbacks for ConfigManager integration
#if CM_ENABLE_SETTINGS_UI
  JsonProvider configJsonProvider;
#endif
#if CM_ENABLE_LIVE_UI
  JsonProvider runtimeJsonProvider;
  std::function<String(const cm::RuntimeSelection&)> selectedRuntimeJsonProvider;
  RuntimeMetaProvider runtimeMetaJsonProvider;
  std::atomic<uint32_t> runtimeMetaActiveRequests{0};
#endif
  SimpleCallback rebootCallback;
#if CM_ENABLE_SETTINGS_UI
  SimpleCallback resetCallback;
  SettingUpdateCallback settingUpdateCallback;
  SettingUpdateCallback settingApplyCallback; // For apply-only operations
#endif

  // Web content
  bool embedWebUI;
  const char* customHTML;
  size_t customHTMLLen;

  // Settings security
  String settingsPassword;

  // Settings authentication token (in-memory)
  String settingsAuthToken;
  uint32_t settingsAuthIssuedAtMs = 0;
  static constexpr uint32_t SETTINGS_AUTH_TTL_MS = 5UL * 60UL * 1000UL; // 5 minutes

  // Helper methods
  void setupStaticRoutes();
  void setupAPIRoutes();
  void setupOTARoutes();
  void setupRuntimeRoutes();
  void setupRuntimeActionRoutes();
  void handleCSSRequest(AsyncWebServerRequest* request);
  void handleJSRequest(AsyncWebServerRequest* request);
  void handleRootRequest(AsyncWebServerRequest* request);
  void handleNotFound(AsyncWebServerRequest* request);
  void handleCaptivePortalProbe(AsyncWebServerRequest* request);

  bool isSettingsAuthRequired() const;
  bool isSettingsAuthValid(AsyncWebServerRequest* request) const;
  String issueSettingsAuthToken();
  bool isCaptivePortalMode() const;
  bool shouldRedirectToPortal(AsyncWebServerRequest* request) const;

  // Utility methods
  String getContentType(const String& path);
  void sendWebUI(AsyncWebServerRequest* request);
  void redirectToPortalRoot(AsyncWebServerRequest* request);
  void enableCORS(AsyncWebServerResponse* response, const char* diagnosticRoute = nullptr);
  void log(const char* format, ...) const;

public:
  // Cppcheck rationale: Preserve implicit construction used by existing callers.
  // cppcheck-suppress noExplicitConstructor
  ConfigManagerWeb(AsyncWebServer* webServer = nullptr);
  ~ConfigManagerWeb();

  void setSelectedRuntimeJsonProvider(std::function<String(const cm::RuntimeSelection&)> provider) {
#if CM_ENABLE_LIVE_UI
    selectedRuntimeJsonProvider = std::move(provider);
#else
    (void)provider;
#endif
  }

  // Initialization
  void begin(ConfigManagerClass* cm);
  void setCallbacks(
    JsonProvider configJson,
    JsonProvider runtimeJson,
    RuntimeMetaProvider runtimeMetaJson,
    SimpleCallback reboot,
    SimpleCallback reset,
    SettingUpdateCallback settingUpdate,
    SettingUpdateCallback settingApply);
  void setCallbacks(
    JsonProvider configJson,
    JsonProvider runtimeJson,
    JsonProvider runtimeMetaJson,
    SimpleCallback reboot,
    SimpleCallback reset,
    SettingUpdateCallback settingUpdate,
    SettingUpdateCallback settingApply);

  // Web content management
  void setEmbedWebUI(bool embed);
  void setCustomHTML(const char* html, size_t length);

  // Server control
  AsyncWebServer* getServer() {
    return server;
  }
  bool isStarted() const;

  // Route management
  void defineAllRoutes();
  void addCustomRoute(const char* path, WebRequestMethodComposite method, RequestHandler handler);

  // CORS and security
  void enableCORSForAll(bool enable = true);
  void setSettingsPassword(const String& password);

  // Development and debugging
#ifdef development
  void addDevelopmentRoutes();
#endif
};
